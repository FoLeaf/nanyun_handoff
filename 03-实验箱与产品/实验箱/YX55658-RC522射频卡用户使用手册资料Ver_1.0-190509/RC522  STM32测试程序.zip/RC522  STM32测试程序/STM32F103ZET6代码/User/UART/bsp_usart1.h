#ifndef __USART1_H
#define	__USART1_H


#include <stdio.h>


void USART1_Config(void);
void NVIC_Configuration(void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);


#endif /* __USART1_H */
